import * as analytics from "./Analytics";

// $(document).ready(function () {
//
//     analytics.initEvent();
//
// });
import {initEvent,growl} from "./Analytics"
let say = growl();